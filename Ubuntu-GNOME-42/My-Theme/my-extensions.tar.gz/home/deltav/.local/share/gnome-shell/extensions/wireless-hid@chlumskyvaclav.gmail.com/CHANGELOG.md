## Version 14
 * remove instances in global scope
## Version 13
 * change to Makefile build system
 * replace DBus with UPower clients
 * fixed a race condition that lead to duplicate devices
 * fixed devices that initially appear as a generic battery then get a device type
 * added a workaround for headsets appearing as keyboards or other devices
 * added an icon name for generic Bluetooth devices
## Version 12
 * fix destroying of devices on disabling (thx to @stuarthayhurst)
## Version 11
 * add Gnome 44 support
## Version 10
 * feature to change the position in top panel
 * improved preferences UI
## Version 9
 * add posibility to hide ELAN devices
 * hide tray icon fix
## Version 8
 * add preferences dialog (Big thx to @stuarthayhurst)
## Version 7
 * add gnome 43 as supported
## Version 6
 * fix battery sync
## Version 5
 * add multiple devices
 * add gnome 42 support
## Version 4
 * hide panel icon without devices
 * ignore ELAN devices
## Version 3
 * fix refreshing percentage
## Version 2
 * remove green color
 * add game controller support
## Version 1
 * initial version